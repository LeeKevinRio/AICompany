# counts.py -- count check for v0.30: base vs trial, consistency base - removed + added == trial.
# usage: python3 -I counts.py [BASE_PATH] [OUT_DIR]   (run build.py first; reads OUT_DIR/trial.md etc.)
# Also compares stage1.md (round-2 reconstruction) with the round-2 hand-in expected table (R2_REF),
# as a fidelity indicator for the reconstruction (differences are reported, not failures).
import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
s = importlib.util.spec_from_file_location('texts', os.path.join(HERE, 'texts.py'))
T = importlib.util.module_from_spec(s)
s.loader.exec_module(T)
base_path = sys.argv[1] if len(sys.argv) > 1 else T.DEFAULT_BASE
out_dir = sys.argv[2] if len(sys.argv) > 2 else HERE


def rd(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


base = rd(base_path)
trial = rd(os.path.join(out_dir, 'trial.md'))
stage1 = rd(os.path.join(out_dir, 'stage1.md'))
removed = rd(os.path.join(out_dir, 'removed.txt'))
added = rd(os.path.join(out_dir, 'added.txt'))

STRINGS = [
    'N-114', 'N114-', 'N114-6', 'N114-7', 'N115-3', 'N-84', 'N-85', 'N-64', 'N-24', 'N-86',
    'V30-', 'V30-01', 'V30-02', 'V30-03', 'V30-04', '| V30-0', 'LG-48', '| LG-48 |',
    '〔v0.30', '〔v0.30 註（V30-01；', '〔v0.30 註（V30-01）：', '〔v0.30 註（V30-02；',
    '〔v0.30 取代：原寫「至 v0.29 為止」，V30-04〕', 'v0.30',
    '草案 v0.30', '草案 v0.29', '至 v0.30 為止', '至 v0.29 為止', '至 v0.28 為止',
    'v0.27～v0.30 修訂 2026-10-24', 'v0.27～v0.29 修訂 2026-10-24',
    '`0213d7a`', 'v0.29 `0213d7a`', 'v0.29 以 `0213d7a`', '`766f9c3`',
    '### v0.29 → v0.30（2026-10-24）', '- **v0.30 狀態**', '- **v0.30 仍需核對**', '**v0.30 新增（本版的依據）**',
    'TA N-114 起草', 'TA N114-6 起草', '風控 2026-10-24 v0.30 逐字確認', '風控 2026-10-25 v0.30 重審',
    '首次判定即終局', '首次判定', '首判', '補判', '本次首判日', '已判定日', '已判定範圍內',
    '「不補造」一點〔v0.30 註〕', 'first_judged_sessions_json', '(vi)', '(i)～(vi)', '讀取時刻',
    'FL-76 (t8)', 'FL-76 (t9)', 'FL-76 (t11)', '(t9)', 'gap_judged_through',
    '#55', '決策包 #55', '決策包二補遺', '決策包 #55 補充', '2026-10-25',
    '放寬面 (c)', '(c) 不在揭露內', '帳目矛盾', '寫入驗證本身的缺陷',
    '最新一個有 ok bars run 的 session', '資料延遲、排程中斷、還原', 'next_session(S)',
    'TG-c', 'late_only', 'basis_json', 'db_restored', 'late=1', 'late=0',
    "`scope_key = '*'`", "`'*'`", 'F-3 缺日率', '逾時率', '缺日稽核冪等批',
    '放寬面', '收緊面', '【推論】', '【推論，TA N-114 起草】', '【推論，TA N114-6 起草】', '〔推論', '【未查證】',
    '本點原文不改〕', '明確同意', 'CEO：**明確同意**',
    '補定義（兩面）', '收緊（揭露）', '不變（揭露）', '不變（文字）', '收緊（測試）',
    'commit 前送風控逐字確認', '不適用相鄰 commit 寬限', '單獨 commit', '不早於 ADR-0027 第一批',
    'coordinator 機械核對：依本版風控逐字確認「下一步」coordinator 一項（核對清單不在本檔重列：引用核對字串會改變它自己的計數）。',
    '之後的 run 可以改變一列的 `reason`', '該日全部排程 run', '殘餘', '由風控裁定',
    '由 coordinator 在風控確認後補入',
    # must be zero in v0.30
    '〔(c) 同意日期〕', '#〔編號〕', '決策包 #〔編號〕', '由風控重審決定', '由 coordinator 在風控重審後補入',
    '由 coordinator 在 CEO 回覆後補入', '〔檔名由 coordinator 補入〕', '由 coordinator 補入', '〔hash〕',
    '交風控裁定', 'next_session(S) 的定案資料',
    # strings that must stay unchanged
    '計入作廢率與 W', '計入最壞情境 W', '計入作廢率、W',
]
MUST_ZERO = set(T.MUST_ZERO) | {'決策包 #〔編號〕'}
UNCHANGED = {'計入作廢率與 W', '計入最壞情境 W', '計入作廢率、W', '`766f9c3`'}

# round-2 hand-in (2026-10-24, section B) expected totals: string -> (count, lines or None)
R2_REF = {
    'N-114': (26, 8), 'N114-': (33, 8), 'N114-6': (18, 8), 'N114-7': (6, 5),
    'V30-': (42, 17), 'V30-01': (19, None), 'V30-02': (13, None), 'V30-03': (4, None), 'V30-04': (6, None),
    'LG-48': (6, 4), '〔v0.30': (19, 11), 'v0.30': (48, 21),
    '首次判定': (24, 9), '首判': (28, 9), '補判': (32, 11),
    'first_judged_sessions_json': (4, None), '(vi)': (15, 8), '讀取時刻': (4, 3), '已判定日': (4, None),
    'FL-76 (t8)': (1, None), 'FL-76 (t11)': (1, None), '(t9)': (1, None),
    'TA N-114 起草': (8, 5), 'TA N114-6 起草': (10, 7), '風控 2026-10-24 v0.30 逐字確認': (9, 5),
    '#55': (4, None), '決策包 #55': (4, None), '決策包 #〔編號〕': (0, None),
    '最新一個有 ok bars run 的 session': (4, 3), '資料延遲、排程中斷、還原': (2, None),
    'TG-c': (9, None), 'late_only': (25, None), 'db_restored': (20, None), 'late=1': (10, None),
    'N-24': (6, None), 'N-84': (6, None), 'N-85': (9, None),
    '放寬面': (56, None), '【推論】': (96, None), '本點原文不改〕': (38, None), '明確同意': (41, None),
    '由 coordinator 在風控確認後補入': (8, None), '由 coordinator 在 CEO 回覆後補入': (1, None),
    '由 coordinator 在風控重審後補入': (3, None), '殘餘': (6, None), '由風控裁定': (1, None),
    'next_session(S) 的定案資料': (0, None), '交風控裁定': (0, None), '由 coordinator 補入': (0, None),
    '計入作廢率與 W': (37, None), '計入最壞情境 W': (6, None), '計入作廢率、W': (1, None),
}


def cnt(txt, sub):
    return sum(line.count(sub) for line in txt.split('\n'))


def lines(txt, sub):
    return sum(1 for line in txt.split('\n') if sub in line)


rows = ['string\tbase\tremoved\tadded\texpected(base-rem+add)\ttrial\ttrial_lines\tconsistent\tnote']
all_ok = True
bad = []
for st in STRINGS:
    b, r, a, t = cnt(base, st), cnt(removed, st), cnt(added, st), cnt(trial, st)
    ok = (b - r + a == t)
    note = []
    if st in MUST_ZERO:
        note.append('MUST_ZERO ' + ('ok' if t == 0 else 'VIOLATED'))
        ok = ok and t == 0
    if st in UNCHANGED:
        note.append('UNCHANGED ' + ('ok' if (t == b and lines(trial, st) == lines(base, st)) else 'VIOLATED'))
        ok = ok and t == b and lines(trial, st) == lines(base, st)
    all_ok = all_ok and ok
    if not ok:
        bad.append(st)
    rows.append('%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s' % (st, b, r, a, b - r + a, t, lines(trial, st), ok, ' '.join(note)))

rows.append('')
rows.append('# fidelity: stage1 (round-2 reconstruction, before R-06..R-13) vs round-2 hand-in expected table')
rows.append('string\tr2_expected\tr2_expected_lines\tstage1\tstage1_lines\tmatch')
nmatch = 0
for st, (c, l) in R2_REF.items():
    s1, s1l = cnt(stage1, st), lines(stage1, st)
    m = (s1 == c) and (l is None or s1l == l)
    nmatch += m
    rows.append('%s\t%d\t%s\t%d\t%d\t%s' % (st, c, '' if l is None else l, s1, s1l, 'same' if m else 'DIFF'))
rows.append('# fidelity summary: %d/%d same' % (nmatch, len(R2_REF)))
rows.append('')
rows.append('ALL_CONSISTENT %s' % all_ok)
with open(os.path.join(out_dir, 'counts.tsv'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(rows) + '\n')
print('lines base %d trial %d' % (base.count('\n'), trial.count('\n')))
print('fidelity %d/%d same as round-2 table' % (nmatch, len(R2_REF)))
if bad:
    print('MISMATCH:', bad)
print('ALL_CONSISTENT', all_ok)
sys.exit(0 if all_ok else 1)
