# build.py -- apply v0.30 edits (texts.py) to a base file and write the trial outputs.
#
# usage: python3 -I build.py [BASE_PATH] [OUT_DIR]
#   BASE_PATH defaults to texts.DEFAULT_BASE (the repo file, v0.29 0213d7a); it is only read.
#   OUT_DIR defaults to this script's directory.
# Outputs: stage1.md (round-2 reconstruction, before R-06..R-13), stage2.md (after R-06..R-13,
#          before V30-R1..R9), trial.md (final),
#          added.txt, removed.txt, hunks.txt, apply_log.txt, final_edits.json
# Exit code 1 on any failed check.
import difflib
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name):
    s = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + '.py'))
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


T = load('texts')
base_path = sys.argv[1] if len(sys.argv) > 1 else T.DEFAULT_BASE
out_dir = sys.argv[2] if len(sys.argv) > 2 else HERE
log = []
fail = []


def say(*a):
    log.append(' '.join(str(x) for x in a))


def check(cond, msg):
    say(('OK   ' if cond else 'FAIL ') + msg)
    if not cond:
        fail.append(msg)


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


base = read(base_path)
say('base:', base_path, 'lines', base.count('\n'), 'chars', len(base))

# ------------------------------------------------ 0. provenance checks against source files
if os.path.exists(T.SRC_R1):
    src = read(T.SRC_R1).split('\n')
    fences, i = [], 0
    while i < len(src):
        if src[i].strip() == '```':
            j = i + 1
            while src[j].strip() != '```':
                j += 1
            fences.append('\n'.join(src[i + 1:j]))
            i = j + 1
        else:
            i += 1
    r1 = load('r1_verbatim')
    names = ['E06', 'E07', 'E09', 'E10', 'E11', 'E12', 'E13', 'E14']
    for n, f in zip(names, fences):
        check(getattr(r1, n + '_R1') == f, 'provenance round-1 %s block == draft fence' % n)
    srctxt = '\n'.join(src)
    for eid, lab, old, new in T.R1_EDITS:
        if eid in ('E-01', 'E-02', 'E-03', 'E-04', 'E-05', 'E-08a', 'E-08b'):
            check(old in srctxt and new in srctxt, 'provenance round-1 %s old/new quoted in draft' % eid)
        elif eid in ('E-09', 'E-10', 'E-11', 'E-12'):
            check(old in srctxt, 'provenance round-1 %s anchor quoted in draft' % eid)
else:
    say('WARN round-1 draft not found; provenance not checked')
if os.path.exists(T.SRC_RISK_A):
    ra = read(T.SRC_RISK_A)
    for k, o, n in T.RISK_A:
        check(('`%s`' % o) in ra and ('`%s`' % n) in ra, 'provenance %s old/new quoted verbatim in risk 2026-10-24 A' % k)
if os.path.exists(T.SRC_Q2):
    q2 = read(T.SRC_Q2)
    check(T.Q2_E09_INSERT in q2, 'provenance Q2 E-09 insertion sentence quoted verbatim in round-2 hand-in')
    check(T.Q2_E12_VI in q2, 'provenance Q2 E-12 (vi)+reading-time sentence quoted verbatim in round-2 hand-in')
if os.path.exists(T.SRC_RISK_R):
    rr = read(T.SRC_RISK_R)
    for k, o, n in T.RISK_R:
        check(('`%s`' % o) in rr and ('`%s`' % n) in rr, 'provenance %s old/new quoted verbatim in risk 2026-10-25 B' % k)

# ------------------------------------------------ 1. compose round-2 'new' strings
r2_new = {eid: new for eid, lab, old, new in T.R1_EDITS}
tag_count = {}
for eid, tag, o, n in T.R2_PATCHES:
    c = r2_new[eid].count(o)
    check(c == 1, 'R2 patch [%s %s] old fragment count in round-1 text == 1 (got %d): %s' % (eid, tag, c, o[:40]))
    r2_new[eid] = r2_new[eid].replace(o, n, 1)
    tag_count.setdefault(eid, {}).setdefault(tag, 0)
    tag_count[eid][tag] += 1
say('R2 patch tags per edit:', json.dumps(tag_count, ensure_ascii=False))


def apply_edits(doc, edits, label):
    for eid, old, new in edits:
        c0 = base.count(old)
        c1 = doc.count(old)
        check(c0 == 1 and c1 == 1, '%s %s old: base %d, at apply %d' % (label, eid, c0, c1))
        doc = doc.replace(old, new, 1)
    return doc


# ------------------------------------------------ 2. stage 1: round-2 reconstruction
stage1 = apply_edits(base, [(e, o, r2_new[e]) for e, l, o, n in T.R1_EDITS], 'stage1')

# ------------------------------------------------ 3. stage 2: risk 2026-10-25 R-06..R-13
risk_r = [(k, o, T.fill_c_date(n)) for k, o, n in T.RISK_R]
trial = stage1
for k, o, n in risk_r:
    c0 = stage1.count(o)
    c1 = trial.count(o)
    check(c0 == 1 and c1 == 1, 'stage2 %s old: stage1 %d, at apply %d' % (k, c0, c1))
    trial = trial.replace(o, n, 1)
say('(c) date placeholders filled:', sum(n.count(T.C_DATE_PLACEHOLDER) for k, o, n in T.RISK_R), '->', T.C_DATE)
stage2 = trial

# ------------------------------------------------ 3b. stage 3: risk 2026-10-25 re-drafted-segment confirmation V30-R1..R9
if os.path.exists(T.SRC_RISK_RR):
    rx = read(T.SRC_RISK_RR)
    for k, o, n in T.RISK_RR:
        check(('`%s`' % o) in rx and ('`%s`' % n) in rx, 'provenance %s old/new quoted verbatim in risk re-drafted-segment confirmation' % k)
for k, o, n in T.RISK_RR:
    c0, c1 = stage2.count(o), trial.count(o)
    check(c0 == 1 and c1 == 1, 'stage3 %s old: stage2 %d, at apply %d' % (k, c0, c1))
    trial = trial.replace(o, n, 1)

# ------------------------------------------------ 4. single-pass final edits (for tech-writer)
final_new = dict(r2_new)
for k, o, n in risk_r + T.RISK_RR:
    hits = [e for e in final_new if final_new[e].count(o) == 1]
    tot = sum(final_new[e].count(o) for e in final_new)
    check(len(hits) == 1 and tot == 1, 'final: %s old lies in exactly one edit (%s)' % (k, ','.join(hits)))
    if hits:
        final_new[hits[0]] = final_new[hits[0]].replace(o, n, 1)
final_edits = [(e, o, final_new[e]) for e, l, o, n in T.R1_EDITS]
trial2 = apply_edits(base, final_edits, 'final')
check(trial2 == trial, 'single-pass final edits on base == layered build (trial)')
with open(os.path.join(out_dir, 'final_edits.json'), 'w', encoding='utf-8') as f:
    json.dump([{'id': e, 'old': o, 'new': n} for e, o, n in final_edits], f, ensure_ascii=False, indent=1)

# ------------------------------------------------ 5. structural checks
for e, o, n in final_edits:
    if e == 'E-07':
        rows = [ln for ln in n.split('\n') if ln.startswith('| V30-0')]
        check(len(rows) == 4 and all(r.count('|') == 7 for r in rows), 'E-07 four revision rows with 7 pipes each')
    elif e == 'E-14':
        row = n.split('\n')[1]
        check(row.startswith('| LG-48 |') and row.count('|') == 3, 'E-14 LG-48 row has 3 pipes')
    elif e in ('E-06', 'E-09', 'E-10', 'E-11', 'E-12', 'E-13'):
        added = n.replace(o, '', 1)
        check('|' not in added, '%s new text contains no "|"' % e)
    if e in ('E-09', 'E-10', 'E-11', 'E-12'):
        check(n.startswith(o), '%s note appended after anchor' % e)
        i = base.find(o) + len(o)
        check(base[i] == '\n', '%s anchor is at end of line in base' % e)

for s in T.MUST_EQUAL_BASE:
    check(trial.count(s) == base.count(s), 'must-equal-base in trial: %s (base %d, trial %d)' % (s, base.count(s), trial.count(s)))
for s in T.MUST_ZERO:
    check(trial.count(s) == 0, 'must-zero in trial: %s (got %d)' % (s, trial.count(s)))
for k, o, n in T.RISK_A:
    check(stage2.count(n) == 1 and stage2.count(o) == 0, 'risk A %s: new 1 / old 0 in stage2' % k)
for k, o, n in risk_r:
    check(stage2.count(n) == 1 and stage2.count(o) == 0, 'risk R %s: new 1 / old 0 in stage2' % k)
for k, o, n in T.RISK_RR:
    check(trial.count(n) == 1 and trial.count(o) == n.count(o), 'risk %s: new 1 / old only inside new, in trial' % k)
check(trial.count('由 coordinator 在風控確認後補入') == 7, '「由 coordinator 在風控確認後補入」 == 7 (got %d)' % trial.count('由 coordinator 在風控確認後補入'))
for e, l, o, n in T.R1_EDITS:
    if e in ('E-01', 'E-02', 'E-03', 'E-04', 'E-05', 'E-08a'):
        k = final_new[e].count(o)
        check(trial.count(o) == k, '%s replaced old count in trial == %d (only inside its new text)' % (e, k))
    else:
        check(trial.count(o) == 1, '%s anchor still exactly 1 in trial' % e)
check(trial.count('風控 2026-10-25 v0.30 重審') >= 5, 'risk re-review short name >= 5 (got %d)' % trial.count('風控 2026-10-25 v0.30 重審'))

# ------------------------------------------------ 6. outputs and hunks
a = base.split('\n')
b = trial.split('\n')
sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
hunks = [op for op in sm.get_opcodes() if op[0] != 'equal']
rem, add, hk = [], [], []
for tag, i1, i2, j1, j2 in hunks:
    rem.append('\n'.join(a[i1:i2]))
    add.append('\n'.join(b[j1:j2]))
    hk.append('%s base L%d-%d (%d) -> trial L%d-%d (%d)' % (tag, i1 + 1, i2, i2 - i1, j1 + 1, j2, j2 - j1))
SEP = '\n=====\n'
for name, txt in (('trial.md', trial), ('stage1.md', stage1), ('stage2.md', stage2)):
    with open(os.path.join(out_dir, name), 'w', encoding='utf-8') as f:
        f.write(txt)
with open(os.path.join(out_dir, 'removed.txt'), 'w', encoding='utf-8') as f:
    f.write(SEP.join(rem) + '\n')
with open(os.path.join(out_dir, 'added.txt'), 'w', encoding='utf-8') as f:
    f.write(SEP.join(add) + '\n')
with open(os.path.join(out_dir, 'hunks.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(hk) + '\n')
say('hunks:', len(hunks))
for h in hk:
    say('  ' + h)
say('lines: base', len(a), '-> stage1', len(stage1.split('\n')), '-> trial', len(b))
say('RESULT', 'ALL_OK' if not fail else 'FAILED %d' % len(fail))
with open(os.path.join(out_dir, 'apply_log.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(log) + '\n')
print('\n'.join(l for l in log if not l.startswith('OK   ')))
sys.exit(1 if fail else 0)
