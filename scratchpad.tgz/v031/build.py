# build.py -- apply v0.31 edits (texts.py) on top of a v0.30 file and write the trial outputs.
#
# usage: python3 -I build.py [BASE_PATH] [OUT_DIR] [V030_HASH]
#   BASE_PATH defaults to ../v030/trial.md (the new v0.30). Any v0.30 text with the same anchors works,
#   e.g. the committed v0.30 after tech-writer lands it. The base is only read.
#   V030_HASH (optional, e.g. 1a2b3c4): fills the 7 `〔hash〕` placeholders with `<hash>`.
# Outputs: stage1.md (before risk R1..R6), stage2.md (before V31-R1..R8), trial.md, added.txt, removed.txt, hunks.txt,
#          apply_log.txt, final_edits.json. Exit code 1 on any failed check.
import difflib
import importlib.util
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name):
    s = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + '.py'))
    m = importlib.util.module_from_spec(s)
    s.loader.exec_module(m)
    return m


T = load('texts')
V = load('v31_verbatim')
base_path = sys.argv[1] if len(sys.argv) > 1 else T.DEFAULT_BASE
out_dir = sys.argv[2] if len(sys.argv) > 2 else HERE
v030_hash = sys.argv[3] if len(sys.argv) > 3 else None
log, fail = [], []


def say(*a):
    log.append(' '.join(str(x) for x in a))


def check(cond, msg):
    say(('OK   ' if cond else 'FAIL ') + msg)
    if not cond:
        fail.append(msg)


def read(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


base = read(base_path)
say('base:', base_path, 'lines', base.count('\n'), 'chars', len(base))

# ------------------------------------------------ 0. provenance
if os.path.exists(T.SRC_DRAFT):
    d = read(T.SRC_DRAFT)
    q = [ln[2:] for ln in d.split('\n') if ln.startswith('> ')]
    check(q == [V.E11_DRAFT, V.E14_DRAFT, V.E10_DRAFT, V.E13_DRAFT, V.E09_DRAFT, V.E12_DRAFT, V.E16_DRAFT],
          'provenance: v31_verbatim == draft blockquotes (7)')
    check('「v0.29 `0213d7a`（單獨 commit）」之後加「、v0.30 `〔hash〕`（與 ADR-0027 缺日稽核冪等批同批 commit）」' in d,
          'provenance: E-04 added item quoted in draft')
if os.path.exists(T.SRC_TA) and os.path.exists(T.SRC_RISK_N17):
    ta = read(T.SRC_TA)
    rk = read(T.SRC_RISK_N17)
    m_orig = re.search(r'被取代的原文：「(涵蓋邊界：只涵蓋.*?一律標「未涵蓋，不計」。)」', ta)
    check(bool(m_orig) and m_orig.group(1) == T.E11_OLD, 'provenance: E-11 old == TA G-Q1 被取代的原文')
    m_new = re.search(r'建議新字：「(涵蓋邊界：涵蓋個股.*?除息日無法解析而未比較的列數。)」', ta)
    g1 = m_new.group(1) if m_new else ''
    for o, n in T.GQ1_RISK:
        check(g1.count(o) == 1 and ('`%s`' % o) in rk and ('`%s`' % n) in rk, 'provenance: G-Q1 risk edit old in TA text / old,new in risk file')
        g1 = g1.replace(o, n, 1)
    head = T.E11_NEW.split('〔v0.31 取代（V31-01')[0]
    check(g1 == head, 'G-Q1: TA suggestion + risk 3 edits == draft E-11 new (before the 取代 record)')
    m2 = re.search(r'G-Q2（強烈建議，§6.4 結算端第 1 點加註）\*\*：「(〔v0.30 註（ADR-0027 N-17）：.*?本點原文不改〕)」', ta)
    g2 = m2.group(1) if m2 else ''
    o, n = T.GQ2_RISK
    check(g2.count(o) == 1 and ('`%s`' % o) in rk and ('`%s`' % n) in rk, 'provenance: G-Q2 risk edit')
    g2 = g2.replace(o, n, 1).replace(T.GQ2_LABEL[0], T.GQ2_LABEL[1], 1)
    check(g2 == V.E14_DRAFT, 'G-Q2: TA note + risk new + label == draft E-14 new')
if os.path.exists(T.SRC_RISK_V31):
    rv = read(T.SRC_RISK_V31)
    for k, o, n in T.RISK_R:
        check(o in rv and n in rv, 'provenance: %s old/new quoted verbatim in risk v0.31 light confirmation' % k)


def apply_edits(doc, edits, label):
    for eid, old, new in edits:
        c0, c1 = base.count(old), doc.count(old)
        check(c0 == 1 and c1 == 1, '%s %s old: base %d, at apply %d' % (label, eid, c0, c1))
        doc = doc.replace(old, new, 1)
    return doc


# ------------------------------------------------ 1. stage1 (draft + re-drafted blocks)
stage1 = apply_edits(base, [(e, o, n) for e, o, n, tag in T.EDITS], 'stage1')
say('edit tags:', json.dumps({e: tag for e, o, n, tag in T.EDITS}, ensure_ascii=False))

# ------------------------------------------------ 2. risk R1..R6
trial = stage1
for k, o, n in T.RISK_R:
    c0, c1 = stage1.count(o), trial.count(o)
    check(c0 == 1 and c1 == 1, 'stage2 %s old: stage1 %d, at apply %d' % (k, c0, c1))
    trial = trial.replace(o, n, 1)
stage2 = trial

# ------------------------------------------------ 2b. risk 2026-10-25 re-drafted-segment confirmation V31-R1..R8
if os.path.exists(T.SRC_RISK_RR):
    rx = read(T.SRC_RISK_RR)
    for k, o, n in T.RISK_RR:
        check(('`%s`' % o) in rx and ('`%s`' % n) in rx, 'provenance %s old/new quoted verbatim in risk re-drafted-segment confirmation' % k)
for k, o, n in T.RISK_RR:
    c0, c1 = stage2.count(o), trial.count(o)
    check(c0 == 1 and c1 == 1, 'stage3 %s old: stage2 %d, at apply %d' % (k, c0, c1))
    trial = trial.replace(o, n, 1)

# ------------------------------------------------ 3. single-pass final edits
final_new = {e: n for e, o, n, tag in T.EDITS}
for k, o, n in T.RISK_R + T.RISK_RR:
    hits = [e for e in final_new if final_new[e].count(o) == 1]
    tot = sum(final_new[e].count(o) for e in final_new)
    check(len(hits) == 1 and tot == 1, 'final: %s old lies in exactly one edit (%s)' % (k, ','.join(hits)))
    if hits:
        final_new[hits[0]] = final_new[hits[0]].replace(o, n, 1)
final_edits = [(e, o, final_new[e]) for e, o, n, tag in T.EDITS]
check(apply_edits(base, final_edits, 'final') == trial, 'single-pass final edits on base == layered build (trial)')
with open(os.path.join(out_dir, 'final_edits.json'), 'w', encoding='utf-8') as f:
    json.dump([{'id': e, 'old': o, 'new': n} for e, o, n in final_edits], f, ensure_ascii=False, indent=1)

if v030_hash:
    assert all(c in '0123456789abcdef' for c in v030_hash) and 7 <= len(v030_hash) <= 40, v030_hash
    filled = '`%s`' % v030_hash
    say('hash fill:', T.HASH, '->', filled, 'count', trial.count(T.HASH))
    trial = trial.replace(T.HASH, filled)
    final_edits = [(e, o, n.replace(T.HASH, filled)) for e, o, n in final_edits]
    with open(os.path.join(out_dir, 'final_edits.json'), 'w', encoding='utf-8') as f:
        json.dump([{'id': e, 'old': o, 'new': n} for e, o, n in final_edits], f, ensure_ascii=False, indent=1)

# ------------------------------------------------ 4. structural checks
for e, o, n in final_edits:
    if e == 'E-07':
        rows = [ln for ln in n.split('\n') if ln.startswith('| V31-0')]
        check(len(rows) == 7 and all(r.count('|') == 7 for r in rows), 'E-07 seven revision rows with 7 pipes each')
    elif e == 'E-16':
        row = n.split('\n')[1]
        check(row.startswith('| LG-49 |') and row.count('|') == 3, 'E-16 LG-49 row has 3 pipes')
    elif e in ('E-06', 'E-09', 'E-10', 'E-11', 'E-13', 'E-14', 'E-15'):
        check('|' not in n.replace(o, '', 1), '%s new text contains no "|"' % e)
    elif e == 'E-12':
        check('|' not in n.replace(o, '', 1), 'E-12 note contains no "|"')
    if e in ('E-09', 'E-10', 'E-12', 'E-13', 'E-14'):
        check(n.startswith(o), '%s note appended after anchor' % e)
for s in T.MUST_EQUAL_BASE:
    check(trial.count(s) == base.count(s), 'must-equal-base in trial: %s (base %d, trial %d)' % (s, base.count(s), trial.count(s)))
for s in T.MUST_ZERO:
    check(trial.count(s) == 0, 'must-zero in trial: %s (got %d)' % (s, trial.count(s)))
check(trial.count(T.HASH) == (0 if v030_hash else 7), '`〔hash〕` == %d (got %d)' % (0 if v030_hash else 7, trial.count(T.HASH)))
for k, o, n in T.RISK_R:
    check(stage2.count(n) == 1 and stage2.count(o) == n.count(o), 'risk %s: new 1 / old only inside new, in stage2' % k)
for k, o, n in T.RISK_RR:
    check(trial.count(n) == 1 and trial.count(o) == n.count(o), 'risk %s: new 1 / old only inside new, in trial' % k)
check(trial.count('由 coordinator 在風控確認後補入') == 7, '「由 coordinator 在風控確認後補入」 == 7 (got %d)' % trial.count('由 coordinator 在風控確認後補入'))
for e, o, n, tag in T.EDITS:
    if e in ('E-01', 'E-02', 'E-03', 'E-04', 'E-05', 'E-08a'):
        k = final_new[e].count(o)
        check(trial.count(o) == k, '%s replaced old count in trial == %d (only inside its new text)' % (e, k))
    else:
        check(trial.count(o) == 1, '%s anchor still exactly 1 in trial' % e)

# ------------------------------------------------ 5. outputs
a, b = base.split('\n'), trial.split('\n')
sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
hunks = [op for op in sm.get_opcodes() if op[0] != 'equal']
rem, add, hk = [], [], []
for tag, i1, i2, j1, j2 in hunks:
    rem.append('\n'.join(a[i1:i2]))
    add.append('\n'.join(b[j1:j2]))
    hk.append('%s base L%d-%d (%d) -> trial L%d-%d (%d)' % (tag, i1 + 1, i2, i2 - i1, j1 + 1, j2, j2 - j1))
SEP = '\n=====\n'
for name, txt in (('trial.md', trial), ('stage1.md', stage1), ('stage2.md', stage2)):
    with open(os.path.join(out_dir, name), 'w', encoding='utf-8') as f:
        f.write(txt)
with open(os.path.join(out_dir, 'removed.txt'), 'w', encoding='utf-8') as f:
    f.write(SEP.join(rem) + '\n')
with open(os.path.join(out_dir, 'added.txt'), 'w', encoding='utf-8') as f:
    f.write(SEP.join(add) + '\n')
with open(os.path.join(out_dir, 'hunks.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(hk) + '\n')
say('hunks:', len(hunks))
for h in hk:
    say('  ' + h)
say('lines: base', base.count('\n'), '-> trial', trial.count('\n'))
say('RESULT', 'ALL_OK' if not fail else 'FAILED %d' % len(fail))
with open(os.path.join(out_dir, 'apply_log.txt'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(log) + '\n')
print('\n'.join(l for l in log if not l.startswith('OK   ')))
sys.exit(1 if fail else 0)
