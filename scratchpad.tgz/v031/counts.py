# counts.py -- count check for v0.31: base (new v0.30) vs trial; base - removed + added == trial.
# usage: python3 -I counts.py [BASE_PATH] [OUT_DIR]   (run build.py first)
# Fidelity: v0.31's own increments in stage1.md (before R1..R6) are compared with the increments
# implied by the v0.31 draft's expected table (draft expected - draft base), which do not depend
# on the v0.30 base. Differences are reported, not failures.
import importlib.util
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
s = importlib.util.spec_from_file_location('texts', os.path.join(HERE, 'texts.py'))
T = importlib.util.module_from_spec(s)
s.loader.exec_module(T)
base_path = sys.argv[1] if len(sys.argv) > 1 else T.DEFAULT_BASE
out_dir = sys.argv[2] if len(sys.argv) > 2 else HERE


def rd(p):
    with open(p, encoding='utf-8') as f:
        return f.read()


base = rd(base_path)
trial = rd(os.path.join(out_dir, 'trial.md'))
stage1 = rd(os.path.join(out_dir, 'stage1.md'))
removed = rd(os.path.join(out_dir, 'removed.txt'))
added = rd(os.path.join(out_dir, 'added.txt'))

# draft table: string -> (draft base, draft expected, expected lines or None)
DRAFT = {
    'N-17': (2, 57, 15), 'N-118': (0, 12, 8), 'N-119': (0, 1, None), 'N-120': (0, 5, 3), 'N-121': (0, 8, 5),
    'N-118～N-121': (0, 3, None), 'N-16': (4, 9, 8),
    'V31-': (0, 67, 23), 'V31-01': (0, 15, None), 'V31-02': (0, 9, None), 'V31-03': (0, 8, None),
    'V31-04': (0, 8, None), 'V31-05': (0, 17, None), 'V31-06': (0, 4, None), 'V31-07': (0, 6, None),
    '| V31-0': (0, 7, None), 'LG-49': (0, 5, 4), '| LG-49 |': (0, 1, None),
    '〔v0.31': (0, 16, 11), '**v0.31 加列**': (0, 1, None), 'v0.31': (0, 44, 24),
    '草案 v0.31': (0, 2, None), '草案 v0.30': (2, 2, None), '至 v0.31 為止': (0, 1, None), '至 v0.30 為止': (1, 2, None),
    '`〔hash〕`': (0, 7, 6), 'v0.30 `〔hash〕`': (0, 5, None), 'v0.30 以 `〔hash〕`': (0, 1, None), '`0213d7a`': (7, 7, None),
    'TA N-17 提案': (0, 16, 11), '風控 2026-10-24 N-17 確認': (0, 17, 10), '決策包二補遺': (0, 5, None),
    'TWT48U_ALL': (1, 3, None), 'dividend_factor_corrected': (0, 2, None), '(丙)': (0, 6, None),
    '(T, T+h]': (1, 10, None), '結算窗 (T, T+h]': (1, 2, None), '結算窗 [T, T+h]': (3, 5, None),
    'E-ADJ-COVERAGE': (4, 15, None), 'E-ADJ-UNUSABLE': (1, 2, None),
    '未涵蓋，不計': (3, 7, None), '永遠看不到': (0, 2, None),
    '【推論】': (94, 100, None), '【未查證】': (8, 10, None),
    '本點原文不改〕': (38, 41, None), '本列原文不改〕': (4, 4, None),
    '由 coordinator 在風控確認後補入': (10, 13, None), 'CEO：知悉': (16, 18, None), '明確同意': (42, 42, None),
    '收緊（揭露）': (44, 47, None), '補定義（兩面）': (52, 54, None), '補定義（不變：依本節欄位表）': (0, 2, None),
    '補定義（收緊：預測端 fail-closed）': (0, 2, None), '不變（揭露）': (44, 46, None), '不變（文字）': (39, 41, None),
    '收緊（測試）': (22, 23, None), '不適用相鄰 commit 寬限': (11, 13, None),
    'coordinator 機械核對：依本版風控': (6, 7, None),
    '計入作廢率與 W': (37, 38, None), '不計入作廢率與 W': (10, 11, None), '計入最壞情境 W': (6, 6, None), '計入作廢率、W': (1, 1, None),
}
EXTRA = ['v0.27～v0.29 修訂 2026-10-24；v0.30～v0.31 修訂 2026-10-25', 'v0.27～v0.29 修訂 2026-10-24；v0.30 修訂 2026-10-25', 'v0.30～v0.31 修訂 2026-10-25',
         '### v0.30 → v0.31（2026-10-25）', '### v0.29 → v0.30（2026-10-25）', 'work/reviews/2026-10-24-v0.31輕量確認-風控.md', '2026-10-24', '計入 (7)', '同時計入 (7)', 'x2_session_removed', '風控 v0.31 輕量確認', 'pending_json', 'fail-closed',
         'adjust_series_pit', 'first_missing_run_id', '〔v0.31 取代', '〔v0.31 註', '決策包 #55', '風控 2026-10-25 v0.30 重審',
         '2026-10-25', '風控 2026-10-25 重擬段確認', '(c)', '或暗示', '並裁定兩件事', '§9.2 並陳兩案', '本版不在 2026-10-24 修訂',
         '已裁定兩件事', '採 fail-closed、不採替代案', '（含風控確認檔）', 'work/reviews/2026-10-25-v0.30與v0.31組字重建-quant.md']
MUST_ZERO = list(T.MUST_ZERO)
STRINGS = list(DRAFT) + EXTRA + MUST_ZERO
UNCHANGED_LINES = {'計入作廢率與 W', '計入最壞情境 W', '計入作廢率、W', '並裁定兩件事'}


def cnt(txt, sub):
    return sum(line.count(sub) for line in txt.split('\n'))


def lines(txt, sub):
    return sum(1 for line in txt.split('\n') if sub in line)


rows = ['string\tbase\tremoved\tadded\texpected(base-rem+add)\ttrial\ttrial_lines\tconsistent\tnote']
all_ok, bad = True, []
for st in STRINGS:
    b, r, a, t = cnt(base, st), cnt(removed, st), cnt(added, st), cnt(trial, st)
    ok = (b - r + a == t)
    note = ''
    if st in MUST_ZERO:
        note = 'MUST_ZERO ' + ('ok' if t == 0 else 'VIOLATED')
        ok = ok and t == 0
    if st in UNCHANGED_LINES:
        same = lines(trial, st) == lines(base, st)
        note = 'LINES_UNCHANGED ' + ('ok' if same else 'VIOLATED')
        ok = ok and same
    if st in ('計入最壞情境 W', '計入作廢率、W', '並裁定兩件事'):
        ok = ok and t == b
    all_ok = all_ok and ok
    if not ok:
        bad.append(st)
    rows.append('%s\t%d\t%d\t%d\t%d\t%d\t%d\t%s\t%s' % (st, b, r, a, b - r + a, t, lines(trial, st), ok, note))

rows.append('')
rows.append('# fidelity: v0.31 own increment in stage1 (before R1..R6) vs draft table increment')
rows.append('string\tdraft_delta\tstage1_delta\tdraft_lines(base 0 only)\tstage1_lines\tmatch')
nm = 0
for st, (db, de, dl) in DRAFT.items():
    d1 = cnt(stage1, st) - cnt(base, st)
    l1 = lines(stage1, st)
    m = (d1 == de - db) and (dl is None or db != 0 or l1 == dl)
    nm += m
    rows.append('%s\t%+d\t%+d\t%s\t%d\t%s' % (st, de - db, d1, '' if (dl is None or db != 0) else dl, l1, 'same' if m else 'DIFF'))
rows.append('# fidelity summary: %d/%d same' % (nm, len(DRAFT)))
rows.append('')
rows.append('ALL_CONSISTENT %s' % all_ok)
with open(os.path.join(out_dir, 'counts.tsv'), 'w', encoding='utf-8') as f:
    f.write('\n'.join(rows) + '\n')
print('lines base %d trial %d' % (base.count('\n'), trial.count('\n')))
print('fidelity %d/%d same as draft increments' % (nm, len(DRAFT)))
if bad:
    print('MISMATCH:', bad)
print('ALL_CONSISTENT', all_ok)
sys.exit(0 if all_ok else 1)
